
package TM03;

public class Ikan {
    boolean statusGantiAir ;
    
    
     boolean status(){
        return statusGantiAir;
    }
}
