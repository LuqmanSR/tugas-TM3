
package TM03;

public class Hewan {
    private String id;
    private String pemilik;
    private boolean statusPenitipan;
    
     String info(){
        return id = pemilik;
    }
    
     boolean status(){
        return statusPenitipan;
    }
}
